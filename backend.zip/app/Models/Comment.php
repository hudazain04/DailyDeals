<?php

namespace App\Models;

use Cassandra\Custom;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


use App\Models\Offer;
use App\Models\Customer;

class Comment extends Model
{
    use HasFactory;
    protected $table ="comments";
    protected $primaryKey="id";
    protected $fillable = ['comment', 'customer_id','offer_id'];

    public function customer()
    {
        return $this->belongsTo(User::class,'customer_id');
    }
    public function offer()
    {
        return $this->belongsTo(Offer::class);
    }
}
