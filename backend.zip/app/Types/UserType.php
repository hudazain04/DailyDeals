<?php

namespace App\Types;

class UserType
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
    public const Admin="Admin";
    public const Customer="Customer";
    public const Merchant="Merchant";
    public const Employee="Employee";

}
