<?php

namespace App\Types;

class OfferType
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
    public const Percentage="Percentage_offer";
    public const Discount="Discount_Offer";
    public const Extra="Extra_Offer";
    public const Gift="Gift_Offer";
}
