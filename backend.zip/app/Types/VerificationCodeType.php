<?php

namespace App\Types;

class VerificationCodeType
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
    public const register_code="Register";
    public const password_code="Password";
}
