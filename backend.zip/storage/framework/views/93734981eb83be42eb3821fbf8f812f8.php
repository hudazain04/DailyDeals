<div class="text-center">
    <h3 >Hello</h3>
    
    <p>Thanks for your registration,Please insert the code below to activation page in application.</p>
    <p><b><?php echo e($code); ?></b></p>
</div>





<?php if(! empty($salutation)): ?>
    <?php echo e($salutation); ?>

<?php else: ?>
    <?php echo app('translator')->get('Best regards'); ?>,<br />DailyDeals Team
<?php endif; ?>
<?php /**PATH C:\Users\jawad\Desktop\DailyDeals\resources\views/verification.blade.php ENDPATH**/ ?>